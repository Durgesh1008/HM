import SwiftUI
import FirebaseFirestore
import Charts
import SwiftSMTP

class HospitalViewModel: ObservableObject {
    @Published var hospital: Hospital
    private let db = Firestore.firestore()
    

    init(hospital: Hospital) {
        self.hospital = hospital
        fetchUpdatedHospitalData()
    }

    func fetchUpdatedHospitalData() {
        guard let hospitalId = hospital.id else { return }

        db.collection("hospitals").document(hospitalId).getDocument { snapshot, error in
            if let error = error {
                print("Error fetching hospital data: \(error.localizedDescription)")
                return
            }
            guard let data = snapshot?.data() else { return }
            
            DispatchQueue.main.async {
                self.hospital.name = data["name"] as? String ?? "Unknown"
                
                if let revenue = data["revenue"] as? Double {
                    self.hospital.revenue = "\(revenue)"
                } else {
                    self.hospital.revenue = "$0"
                }
                
                if let unpaidDues = data["unpaidDues"] as? Double {
                    self.hospital.unpaidDues = "\(unpaidDues)"
                } else {
                    self.hospital.unpaidDues = "$0"
                }
                
                if let expenses = data["expenses"] as? Double {
                    self.hospital.expenses = "\(expenses)"
                } else {
                    self.hospital.expenses = "$0"
                }

                if let adminData = data["admin"] as? [String: Any] {
                    self.hospital.admin.name = adminData["name"] as? String ?? "Unknown"
                    self.hospital.admin.email = adminData["email"] as? String ?? "Unknown"
                    self.hospital.admin.address = adminData["address"] as? String ?? "Unknown"
                    self.hospital.admin.phoneNumber = adminData["phoneNumber"] as? String ?? "Unknown"
                }
            }
        }
    }
}

struct HospitalDetailView: View {
    @StateObject private var viewModel: HospitalViewModel
    @State private var isEditPresented = false
    @State private var showingAlert = false
    @State private var alertMessage = ""

    init(hospital: Hospital) {
        _viewModel = StateObject(wrappedValue: HospitalViewModel(hospital: hospital))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(viewModel.hospital.name)
                .font(.largeTitle)
                .bold()
                .padding(.horizontal)

            ChartView(hospital: viewModel.hospital)
                .frame(height: 200)
                .padding(.horizontal)

            HStack(spacing: 16) {
                InfoCard(title: "Total Revenue", value: viewModel.hospital.revenue ?? "$0", color: .green)
                InfoCard(title: "Unpaid Dues", value: viewModel.hospital.unpaidDues ?? "$0", color: .blue)
                InfoCard(title: "Expenses", value: viewModel.hospital.expenses ?? "$0", color: .red)
            }
            .padding(.horizontal)

            List {
                if let hospitalId = viewModel.hospital.id {
                    NavigationLink(destination: EditAdmin(admin: viewModel.hospital.admin, hospitalId: hospitalId)) {
                        HStack {
                            Text("Admin")
                            Spacer()
                        }
                    }
                } else {
                    Text("Hospital ID is missing")
                        .foregroundColor(.red)
                }

                Section(header: Text("Admin Details")) {
                    Text("Name: \(viewModel.hospital.admin.name)")
                    
                    HStack {
                        Text("Email: \(viewModel.hospital.admin.email)")
                        Spacer()
                        Button(action: {
                            if let hospitalId = viewModel.hospital.id {
                                sendEmail(to: viewModel.hospital.admin.email, hospitalId: hospitalId) { success, message in
                                    DispatchQueue.main.async {
                                        alertMessage = message
                                        showingAlert = true
                                    }
                                }
                            } else {
                                alertMessage = "Hospital ID is missing."
                                showingAlert = true
                            }
                        }) {
                            Image(systemName: "arrow.right.circle.fill")
                                .foregroundColor(.blue)
                        }
                    }

                    
                    Text("Address: \(viewModel.hospital.admin.address)")
                    Text("Phone: \(viewModel.hospital.admin.phoneNumber)")
                }
            }
        }
        .navigationTitle("Hospital Detail")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Edit") {
                    isEditPresented = true
                }
            }
        }
        .sheet(isPresented: $isEditPresented, onDismiss: {
            viewModel.fetchUpdatedHospitalData()
        }) {
            EditHospital(hospital: $viewModel.hospital)
        }
        .onAppear {
            viewModel.fetchUpdatedHospitalData()
        }
        .alert(isPresented: $showingAlert) {
            Alert(title: Text("Email Status"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
}

func generateRandomPassword() -> String {
    let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    return String((0..<6).map { _ in characters.randomElement()! })
}

// MARK: - Send Email Function
func sendEmail(to email: String, hospitalId: String, completion: @escaping (Bool, String) -> Void) {
    let smtp = SMTP(
        hostname: "smtp.gmail.com",
        email: "sethidevangsethi@gmail.com",
        password: "pjwp uynj foxi rfov",
        port: 465,
        tlsMode: .requireTLS
    )
    
    let randomPassword = generateRandomPassword()  // Generate a password

    let from = Mail.User(name: "Hospital Team", email: "sethidevangsethi@gmail.com")
    let to = Mail.User(name: "User", email: email)
    
    let mail = Mail(
        from: from,
        to: [to],
        subject: "Login Credentials",
        text: "Your login details:\nEmail: \(email)\nPassword: \(randomPassword)"
    )
    
    smtp.send(mail) { error in
        if let error = error {
            completion(false, "Error sending email: \(error.localizedDescription)")
        } else {
            // Save the generated password in Firestore under the admin data
            let db = Firestore.firestore()
            let adminRef = db.collection("hospitals").document(hospitalId)

            adminRef.updateData([
                "admin.password": randomPassword // Storing password in Firestore
            ]) { dbError in
                if let dbError = dbError {
                    completion(false, "Email sent but failed to save password: \(dbError.localizedDescription)")
                } else {
                    completion(true, "Email Credentials send successfully.")
                }
            }
        }
    }
}



// MARK: - ChartView
struct ChartView: View {
    var hospital: Hospital

    var body: some View {
        VStack {
            Text("11 Feb 2025").font(.caption)

            Chart {
                BarMark(
                    x: .value("Category", "Revenue"),
                    y: .value("Amount", Double(hospital.revenue ?? "0") ?? 0.0)
                )
                .foregroundStyle(.green)

                BarMark(
                    x: .value("Category", "Dues"),
                    y: .value("Amount", Double(hospital.unpaidDues ?? "0") ?? 0.0)
                )
                .foregroundStyle(.blue)

                BarMark(
                    x: .value("Category", "Expenses"),
                    y: .value("Amount", Double(hospital.expenses ?? "0") ?? 0.0)
                )
                .foregroundStyle(.red)
            }
            .chartYAxis {
                AxisMarks(position: .leading)
            }
        }
    }
}

// MARK: - InfoCard
struct InfoCard: View {
    var title: String
    var value: String
    var color: Color
    
    var body: some View {
        VStack {
            Text(title).font(.headline)
            Text(value).foregroundColor(color).font(.title3)
        }
        .frame(maxWidth: .infinity, minHeight: 100)
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 3)
    }
}

// MARK: - Preview
struct HospitalDetailView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleHospital = Hospital(
            id: "1",
            name: "Sample Hospital",
            location: "New York",
            admin: Admin(
                id: "09", name: "John Doe",
                email: "admin@hospital.com",
                address: "123 Main St, NY",
                experience: "10 Years",
                phoneNumber: "(123) 456-7890"
            ),
            revenue: "$500,000",
            unpaidDues: "$50,000",
            expenses: "$200,000"
        )
        
        return NavigationStack {
            HospitalDetailView(hospital: sampleHospital)
        }
    }
}
