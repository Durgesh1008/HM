import SwiftUI

struct DoctorDashboardView: View {
    let doctor: DoctorModel // Ensure doctorData is properly initialized
    let hospitalId: String
    
    var body: some View {
        NavigationStack {
            TabView {
                HomeView(doctor: doctor)
                    .tabItem {
                        Image(systemName: "house.fill")
                        Text("Dashboard")
                    }
                    .navigationTitle("Home")
                    .navigationBarTitleDisplayMode(.inline)

                LeaveRequestView(doctorId: doctor.id, hospitalId: hospitalId)
                    .tabItem {
                        Image(systemName: "briefcase.fill")
                        Text("Leave")
                    }
                    .navigationTitle("Leave Dashboard")
                    .navigationBarTitleDisplayMode(.inline)

                SettingsView(doctor: doctor) // Corrected doctor parameter
                    .tabItem {
                        Image(systemName: "gearshape.fill")
                        Text("Settings")
                    }
                    .navigationTitle("Settings")
                    .navigationBarTitleDisplayMode(.inline)
            }
        }
    }
}

// MARK: - Preview with Dummy Data


// MARK: - Prescription View
struct PrescriptionView: View {
    let patient: Patient
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Prescription for \(patient.name)")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                
                ForEach(samplePrescriptions, id: \.id) { prescription in // Fixed typo here
                    DetailField(label: prescription.date, value: prescription.details)
                }
            }
            .padding()
        }
        .navigationTitle("Prescription")
    }
}

// MARK: - Sample Prescriptions Data
struct Prescription: Identifiable {
    let id = UUID()
    let date: String
    let details: String
}

let samplePrescriptions = [
    Prescription(date: "15 Feb 2025", details: "Amoxicillin 500mg - Twice a day for 7 days"),
    Prescription(date: "14 Feb 2025", details: "Ibuprofen 200mg - As needed for pain"),
    Prescription(date: "10 Feb 2025", details: "Vitamin D Supplements - Once a day")
]

// MARK: - Reusable Detail Field Component
struct DetailField: View {
    let label: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label)
                .font(.caption)
                .foregroundColor(.gray)
            Text(value)
                .font(.headline)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemGray6))
        .cornerRadius(8)
    }
}

#Preview {
    DoctorDashboardView(doctor: DoctorModel(
        id: "1",
        firstName: "John",
        lastName: "Doe",
        specialization: "Cardiology", phone: "1234567890",
        email: "john.doe@example.com",
        experience: "10",
        degrees: ["MBBS", "MD"],
        medicalLicenseId: "MED12345",
        bankAccountNumber: "9876543210",
        address: "123 Main St, New York"
    ), hospitalId: "dummyHospitalId")
}

