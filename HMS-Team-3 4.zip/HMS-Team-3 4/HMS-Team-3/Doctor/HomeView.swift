import SwiftUI
import Firebase
import FirebaseFirestore

struct HomeView: View {
    @State private var selectedTab = 0
    @State private var upcomingAppointments: [SeeAppointment] = []
    @State private var completedAppointments: [SeeAppointment] = []
    
    var doctor: DoctorModel

    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Dr. \(doctor.firstName) \(doctor.lastName)")
                            .font(.title2)
                            .fontWeight(.bold)

                        Text("Appointments")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                    }
                    Spacer()
                }
                .padding()
                
                Picker("", selection: $selectedTab) {
                    Text("Upcoming").tag(0)
                    Text("Completed").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()
                
                if filteredAppointments.isEmpty {
                    Spacer()
                    Text(selectedTab == 0 ? "You don't have any upcoming appointments." : "No completed appointments yet.")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                    Spacer()
                } else {
                    ScrollView {
                        VStack(spacing: 15) {
                            ForEach(filteredAppointments) { appointment in
                                NavigationLink(destination: AppointmentDetailView(appointment: appointment, doctorId: doctor.id, onUpdate: {
                                    fetchAppointments() // ✅ Ensure data refreshes
                                })) {
                                    AppointmentCard(appointment: appointment)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                fetchAppointments()  // ✅ Auto-refresh when HomeView appears
            }
        }
    }
    
    private var filteredAppointments: [SeeAppointment] {
        selectedTab == 0 ? upcomingAppointments : completedAppointments
    }
    
    private func fetchAppointments() {
        let db = Firestore.firestore()
        let doctorRef = db.collection("doctors").document(doctor.id)
        
        doctorRef.getDocument { document, error in
            if let document = document, document.exists {
                if let data = document.data(), let appointmentsArray = data["appointments"] as? [[String: Any]] {
                    let appointments = appointmentsArray.compactMap { dict -> SeeAppointment? in
                        guard let patient = dict["patient"] as? String,
                              let time = dict["time"] as? String,
                              let status = dict["status"] as? String,
                              let userId = dict["userId"] as? String else { return nil }
                        return SeeAppointment(id: UUID().uuidString, patient: patient, time: time, status: status, userId: userId)
                    }
                    
                    DispatchQueue.main.async {
                        self.upcomingAppointments = appointments.filter { $0.status == "Pending" }
                        self.completedAppointments = appointments.filter { $0.status == "Approved" || $0.status == "Completed" }
                    }
                }
            } else if let error = error {
                print("Error fetching doctor appointments: \(error.localizedDescription)")
            }
        }
    }
}

/// ✅ Appointment Model
struct SeeAppointment: Identifiable {
    var id: String
    var patient: String
    var time: String
    var status: String
    var userId: String
}

/// ✅ Appointment Card (Reusable)
struct AppointmentCard: View {
    var appointment: SeeAppointment

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Patient: \(appointment.patient)")
                .font(.headline)
                .foregroundColor(.primary)

            Text("Time: \(appointment.time)")
                .font(.subheadline)
                .foregroundColor(.gray)

            Text("Status: \(appointment.status)")
                .font(.footnote)
                .foregroundColor(appointment.status == "Completed" ? .green : (appointment.status == "Approved" ? .blue : .yellow))
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
}

/// ✅ Appointment Detail View
struct AppointmentDetailView: View {
    var appointment: SeeAppointment
    var doctorId: String
    var onUpdate: () -> Void
    
    @State private var status: String
    @Environment(\.presentationMode) var presentationMode
    @State private var showSuccessMessage = false
    
    init(appointment: SeeAppointment, doctorId: String, onUpdate: @escaping () -> Void) {
        self.appointment = appointment
        self.doctorId = doctorId
        self.onUpdate = onUpdate
        _status = State(initialValue: appointment.status)
    }
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Patient: \(appointment.patient)")
                .font(.title2)
                .fontWeight(.bold)
            
            Text("Time: \(appointment.time)")
                .font(.headline)
            
            Text("Status: \(status)")
                .font(.headline)
                .foregroundColor(status == "Completed" ? .green : (status == "Approved" ? .blue : .yellow))
            
            if status == "Pending" {
                Button(action: {
                    approveAppointment()
                }) {
                    Text("Approve")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .cornerRadius(8)
                }
                .padding(.horizontal)
            }
            
            if showSuccessMessage {
                Text("✅ Appointment Approved Successfully!")
                    .foregroundColor(.green)
                    .font(.headline)
                    .padding(.top, 10)
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("Appointment Details")
    }
    
    private func approveAppointment() {
        let db = Firestore.firestore()
        let doctorRef = db.collection("doctors").document(doctorId)
        
        doctorRef.getDocument { document, error in
            if let document = document, document.exists {
                if var appointmentsArray = document.data()?["appointments"] as? [[String: Any]] {
                    
                    // Find the correct appointment using patient & time
                    if let index = appointmentsArray.firstIndex(where: {
                        ($0["userId"] as? String == appointment.userId) &&
                        ($0["time"] as? String == appointment.time)
                    }) {
                        // Update the status
                        appointmentsArray[index]["status"] = "Approved"
                        
                        // Write back to Firestore
                        doctorRef.updateData(["appointments": appointmentsArray]) { error in
                            if let error = error {
                                print("Error updating appointment: \(error.localizedDescription)")
                            } else {
                                DispatchQueue.main.async {
                                    self.status = "Approved"
                                    self.showSuccessMessage = true
                                    
                                    // ✅ Auto-refresh HomeView after approval
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                        self.presentationMode.wrappedValue.dismiss()
                                        self.onUpdate()  // Ensures HomeView reloads
                                    }
                                }
                            }
                        }
                    } else {
                        print("Error: Appointment not found in array.")
                    }
                } else {
                    print("Error: Appointments array not found.")
                }
            } else if let error = error {
                print("Error fetching doctor document: \(error.localizedDescription)")
            }
        }
    }
}
/// ✅ Preview Example
#Preview {
    HomeView(doctor: DoctorModel(
        id: "12345",
        firstName: "John",
        lastName: "Doe",
        specialization: "Cardiologist",
        phone: "123-456-7890",
        email: "johndoe@example.com",
        experience: "10",
        degrees: ["MD", "PhD"],
        medicalLicenseId: "MED123456",
        bankAccountNumber: "9876543210",
        address: "123 Main Street, City, Country"
    ))
}
