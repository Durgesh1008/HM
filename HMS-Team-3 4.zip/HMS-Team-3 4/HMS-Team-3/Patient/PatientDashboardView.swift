//
//  PatientDashboardView.swift
//  HMS_DOCTOR
//
//  Created by Udaibir Singh Bhathal on 18/02/25.
//


import SwiftUI
import FirebaseFirestore

struct PatientDashboardView: View {
    @State private var showEmergencyAlert: Bool = false
    var hospitalName: String
    @State private var isScrolled = false
    var hospitalLocation: String
    let patientEmail : String
    let specializationIcons: [String: String] = [
        "General":"stethoscope",
        "General Medicine": "stethoscope",
        "Nephrology": "drop.fill",
        "Nephrologist": "drop.fill",
        "Cardiology": "heart.fill",
        "Cardiologist": "heart.fill",
        "Neurology": "brain.head.profile",
        "Neurologist": "brain.head.profile",
        "Dentistry": "mouth.fill",
        "Dentist": "mouth.fill",
        "Obstetrics and Gynecology": "person.2.fill",
        "OB-GYN": "person.2.fill",
        "Pediatrics": "figure.child",
        "Pediatrician": "figure.child",
        "Surgery": "scissors",
        "Surgeon": "scissors",
        "Orthopedics": "figure.walk",
        "Orthopedic": "figure.walk",
        "Dermatology": "sun.max.fill",
        "Dermatologist": "sun.max.fill",
        "ENT": "ear.fill",
        "ENT Specialist": "ear.fill",
        "Psychiatry": "brain",
        "Psychiatrist": "brain",
        "Ophthalmology": "eye.fill",
        "Ophthalmologist": "eye.fill",
        "Endocrinology": "drop.circle.fill",
        "Endocrinologist": "drop.circle.fill",
        "Urology": "bolt.heart.fill",
        "Urologist": "bolt.heart.fill",
        "Oncology": "stethoscope",
        "Oncologist": "stethoscope",
        "Pulmonology": "lungs.fill",
        "Pulmonologist": "lungs.fill",
        "Gastroenterology": "rectangle.portrait.and.arrow.right.fill",
        "Gastroenterologist": "rectangle.portrait.and.arrow.right.fill",
        "Hematology": "drop.triangle.fill",
        "Hematologist": "drop.triangle.fill",
        "Rheumatology": "figure.wave",
        "Rheumatologist": "figure.wave",
        "Anesthesiology": "bed.double.fill",
        "Anesthesiologist": "bed.double.fill",
        "Radiology": "waveform.path.ecg",
        "Radiologist": "waveform.path.ecg",
        "Pathology": "testtube.2",
        "Pathologist": "testtube.2",
        "Immunology": "allergens",
        "Immunologist": "allergens",
        "Neurosurgery": "brain.filled.head.profile",
        "Neurosurgeon": "brain.filled.head.profile",
        "Plastic Surgery": "person.crop.rectangle",
        "Plastic Surgeon": "person.crop.rectangle",
        "Thoracic Surgery": "lungs.fill",
        "Thoracic Surgeon": "lungs.fill",
        "Hepatology": "pills.fill",
        "Hepatologist": "pills.fill",
        "Toxicology": "exclamationmark.triangle.fill",
        "Toxicologist": "exclamationmark.triangle.fill",
        "Geriatrics": "figure.older",
        "Geriatrician": "figure.older",
        "Podiatry": "shoe.fill",
        "Podiatrist": "shoe.fill",
        "Otolaryngology": "ear",
        "Otolaryngologist": "ear",
        "Sports Medicine": "figure.run",
        "Sports Physician": "figure.run",
        "Emergency Medicine": "cross.fill",
        "Emergency Physician": "cross.fill",
        "Intensive Care": "bed.double.circle.fill",
        "Critical Care Medicine": "bed.double.circle.fill",
        "Neonatology": "figure.baby",
        "Neonatologist": "figure.baby"
    ]


    
    @State private var hospitalId: String = "" // ✅ Store fetched hospitalId
    @State private var specializations: [SpecializationModel] = []
    @State private var doctors: [DoctorModel] = []
    
    var body: some View {
        NavigationStack {
            
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Specialties Section
                    HStack(alignment: .center, spacing: 8) {
                        HStack {
                            Text("Specialties")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        
                        NavigationLink(destination: Specialization(specializations: specializations, doctors: doctors)) {
                            Text("See All")
                                .foregroundColor(.blue)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                    }
                    .padding(.horizontal)
                    
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 16), count: 4), spacing: 16) {
                        ForEach(specializations.prefix(8), id: \.name) { specialization in
                            SpecialtyCard(specialization: specialization, doctors: doctors)
                        }
                    }
                    .padding(.horizontal)
                    
                    // Doctors Section
                    HStack(alignment: .center, spacing: 8) {
                        HStack {
                            Text("Doctors")
                                .font(.title2)
                                .bold()
                            Spacer()
                        }
                        
                        NavigationLink(destination: DoctorList(doctors: doctors)) {
                            Text("See All")
                                .foregroundColor(.blue)
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        }
                    }
                    .padding(.horizontal)
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(doctors.prefix(4), id: \.id) { doctor in
                                NavigationLink(destination: PatientDoctorDetailView(doctor: doctor)) {
                                    DoctorCard(doctor: doctor)
                                }
                            }
                        }
                        .padding(.top,10)
                        .padding(.bottom,10)
                        .padding(.horizontal)
                        
                    }
                    
                    // Health Initiatives Section
                    Text("Our Latest Health Initiatives")
                        .font(.title2)
                        .bold()
                        .padding(.horizontal)
                    

                    VStack(spacing: 16) {
                        HealthInitiativeCard(title: "360° Woodlands Healthcare", description: "Comprehensive healthcare solutions.", systemImage: "stethoscope")
                        HealthInitiativeCard(title: "Advanced Cardiac Care", description: "Hospital in Surat", systemImage: "heart.text.square.fill")
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .navigationTitle(hospitalName)  // ✅ Set navigation title
            .navigationBarTitleDisplayMode(.automatic) // ✅ System handles title transition
            .onPreferenceChange(ScrollOffsetKey.self) { value in
                isScrolled = value < -50  // ✅ Adjust threshold for smoother transition
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    VStack(spacing: isScrolled ? 0 : 2) { // Reduce spacing when scrolling
                        Text(hospitalLocation)
                            .font(.caption)
                            .foregroundColor(.gray)
                            .opacity(isScrolled ? 0 : 1) // ✅ Hide location in inline mode
                    }
                    .animation(.easeInOut(duration: 0.3), value: isScrolled)
                }
            }// ✅ Adds navigation bar title
            .background(Color(UIColor.systemGray6))
            .onAppear {
                fetchHospitalId(from: hospitalName, location: hospitalLocation) { id in
                    if let id = id {
                        self.hospitalId = id
                        fetchSpecializations(for: id) // ✅ Fetch specializations after getting hospitalId
                        fetchDoctors(for: id) // ✅ Fetch doctors after getting hospitalId
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showEmergencyAlert = true
                    }) {
                        Image(systemName: "cross.circle.fill")
                            .foregroundColor(.red)
                    }
                    .alert("Emergency", isPresented: $showEmergencyAlert) {
                        Button("Cancel", role: .cancel) { }
                        Button("Book", role: .destructive) {
                            // Handle emergency booking action
                        }
                    } message: {
                        Text("You are about to book an ambulance. Are you sure you want to proceed?")
                    }
                }
            }
        }
    }
    
    /// ✅ **Fetch `hospitalId` from Firestore using `hospitalName` & `hospitalLocation`**
    func fetchHospitalId(from name: String, location: String, completion: @escaping (String?) -> Void) {
        let db = Firestore.firestore()
        
        db.collection("hospitals")
            .whereField("name", isEqualTo: name)
            .whereField("location", isEqualTo: location)
            .getDocuments { snapshot, error in
                if let error = error {
                    print("❌ Error fetching hospitalId: \(error.localizedDescription)")
                    completion(nil)
                    return
                }
                
                guard let document = snapshot?.documents.first else {
                    print("❌ No hospital found for name: \(name) & location: \(location)")
                    completion(nil)
                    return
                }
                
                let hospitalId = document.documentID  // ✅ Firestore's document ID as `hospitalId`
                completion(hospitalId)
            }
    }
    
    
    
    /// ✅ **Fetch Doctors from Firestore Filtered by `hospitalId`**
    /// ✅ **Fetch Doctors from Firestore Filtered by `hospitalId`**
    func fetchDoctors(for hospitalId: String) {
        let db = Firestore.firestore()
        db.collection("doctors")
            .whereField("hospitalId", isEqualTo: hospitalId) // ✅ Fixed to filter by hospitalId
            .getDocuments { snapshot, error in
                if let error = error {
                    print("❌ Error fetching doctors: \(error.localizedDescription)")
                    return
                }
                guard let documents = snapshot?.documents else { return }
                
                self.doctors = documents.compactMap { doc -> DoctorModel? in
                    let data = doc.data()
                    guard let firstName = data["firstName"] as? String,
                          let lastName = data["lastName"] as? String,
                          let specialization = data["specialization"] as? String,
                          let phone = data["phone"] as? String,
                          let email = data["email"] as? String,
                          let experience = data["experience"] as? String,
                          let degrees = data["degrees"] as? [String],
                          let medicalLicenseId = data["medicalLicenseId"] as? String,
                          let bankAccountNumber = data["bankAccountNumber"] as? String,
                          let address = data["address"] as? String else {
                        return nil
                    }
                    return DoctorModel(
                        id: doc.documentID,
                        firstName: firstName,
                        lastName: lastName,
                        specialization: specialization,
                        phone: phone,
                        email: email,
                        experience: experience,
                        degrees: degrees,
                        medicalLicenseId: medicalLicenseId,
                        bankAccountNumber: bankAccountNumber,
                        address: address
                    )
                }
            }
    }
    
    /// ✅ **Fetch Specializations from Firestore Filtered by `hospitalId`**
    func fetchSpecializations(for hospitalId: String) {
        let db = Firestore.firestore()
        
        db.collection("specializations")
            .whereField("hospitalId", isEqualTo: hospitalId)  // ✅ Filter by `hospitalId`
            .getDocuments { snapshot, error in
                if let error = error {
                    print("❌ Error fetching specializations: \(error.localizedDescription)")
                    return
                }
                
                guard let documents = snapshot?.documents else {
                    print("❌ No specializations found for hospitalId: \(hospitalId)")
                    return
                }
                
                let fetchedSpecializations = documents.compactMap { doc -> SpecializationModel? in
                    let data = doc.data()
                    guard let name = data["name"] as? String,
                          let description = data["description"] as? String else {
                        return nil
                    }
                    
                    // Map specialization name to SF Symbol
                    let imageName = specializationIcons[name] ?? "questionmark.circle" // Default if not found
                    
                    return SpecializationModel(name: name, description: description, imageName: imageName)
                }
                
                DispatchQueue.main.async {
                    self.specializations = fetchedSpecializations
                }
            }
    }

    
    
    
    
    
    struct SpecialtyCard: View {
        let specialization: SpecializationModel
        let doctors: [DoctorModel]
        
        var body: some View {
            NavigationLink(destination: SpecialisationDoctorView(specialization: specialization)) {
                VStack {
                    Image(systemName: specialization.imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    
                    Text(specialization.name)
                        .font(.footnote)
                        .fontWeight(.medium)
                        .foregroundColor(.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .frame(width: 70)
                }
            }
        }
    }
    
    
    
    
    struct SpecialtyDetailView: View {
        var specialtyName: String
        
        var body: some View {
            VStack {
                Text(specialtyName)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                
                Text("Detailed information about \(specialtyName) services and treatments.")
                    .padding()
                
                Spacer()
            }
            .navigationTitle(specialtyName)
        }
    }
    
    struct DoctorProfileView: View {
        var doctorName: String
        var specialty: String
        var fee: String
        
        var body: some View {
            VStack {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .foregroundColor(.blue)
                    .padding()
                
                Text(doctorName)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text(specialty)
                    .font(.title2)
                    .foregroundColor(.gray)
                    .padding(.bottom, 10)
                
                Text("Appointment Fee: \(fee)")
                    .font(.title3)
                    .foregroundColor(.green)
                
                Spacer()
            }
            .navigationTitle(doctorName)
        }
    }
    
    struct HealthInitiativeCard: View {
        var title: String
        var description: String
        var systemImage: String
        
        var body: some View {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Image(systemName: systemImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60) // Ensure equal icon size
                        .foregroundColor(.blue)
                        .padding(10)
//                        .background(Color(.systemGray6))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    
                    Spacer()
                }
                
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                
                Spacer()
            }
            .frame(height: 180) // Ensures all cards are the same height
            .padding()
            .background(Color(.systemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
    }
    
    
    // MARK: - Dummy Views for "See All"
    
    struct SpecialtiesView: View {
        var body: some View {
            Text("All Specialties")
                .font(.title)
        }
    }
    
    struct DoctorsView: View {
        var body: some View {
            Text("All Doctors")
                .font(.title)
        }
    }
}
// MARK: - Preview

#Preview {
    PatientDashboardView(hospitalName: "HMS", hospitalLocation: "INDIA", patientEmail: "patient@gmail.com")
}
struct ScrollOffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}
