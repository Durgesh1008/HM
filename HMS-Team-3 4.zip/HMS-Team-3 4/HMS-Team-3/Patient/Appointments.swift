import SwiftUI

// MARK: - Appointment Model


struct Appointments: View {
    @State private var selectedTab = "Scheduled"
    @ObservedObject var appointmentManager = AppointmentManager.shared
    var patientEmail:String
    var body: some View {
        NavigationStack { // Wrap the content in NavigationStack instead of NavigationView
            VStack {
                // Picker for Scheduled/Completed
                Picker("Appointments", selection: $selectedTab) {
                    Text("Scheduled").tag("Scheduled")
                    Text("Completed").tag("Completed")
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                // List of Appointments
                List {
                    if selectedTab == "Scheduled" {
                        
                        ForEach(appointmentManager.scheduledAppointments) { appointment in
                            let doctorFees = appointmentManager.doctorFeesDict[appointment.doctorName] ?? "N/A"
                            NavigationLink(destination: ScheduleAppointment(appointment: DoctorAppointment(
                                doctorName: appointment.doctorName,
                                specialty: appointment.specialty,
                                appointmentDate: appointment.appointmentDate,
                                appointmentSlot: appointment.appointmentSlot,
                                paymentStatus: doctorFees,
                                paymentState: "Unpaid",
                                appointmentId: appointment.id.uuidString
                            ))) {
                                AppointmentRow(
                                        appointment: appointment,
                                        doctorFees: appointmentManager.doctorFeesDict[appointment.doctorName] ?? "N/A" // ✅ Pass Fees Separately
                                    )

                            }
                        }
                    } else {
                        ForEach(appointmentManager.completedAppointments) { appointment in
                            NavigationLink(destination: CompletedAppointment(appointment: DoctorAppointment(
                                doctorName: appointment.doctorName,
                                specialty: appointment.specialty,
                                appointmentDate: appointment.appointmentDate,
                                appointmentSlot: appointment.appointmentSlot,
                                paymentStatus: "500",
                                paymentState: "Paid",
                                appointmentId: appointment.id.uuidString
                            ))) {
                                AppointmentRow(
                                        appointment: appointment,
                                        doctorFees: appointmentManager.doctorFeesDict[appointment.doctorName] ?? "N/A"
                                    )

                            }
                        }
                    }
                }
                .listStyle(PlainListStyle())
                .background(Color(.systemGray6))
            }
            .navigationBarItems(trailing:
                                    NavigationLink(destination: BookAppointmentSelectionView(patientManager: PatientManager(),patientEmail:patientEmail)
                    .environmentObject(appointmentManager)
                ) {
                    Image(systemName: "plus")
                        .font(.title2)
                }
            )
            .background(Color(UIColor.systemGray6))
            .navigationTitle("Appointments")
            .navigationBarTitleDisplayMode(.large) // Optional: Adjust the display mode
            .onAppear {
                appointmentManager.setPatientEmail(patientEmail) // ✅ Pass patient email to fetch correct appointments
            }
        }
    }
}

// MARK: - Appointment Row View
struct AppointmentRow: View {
    let appointment: Appointment
    let doctorFees: String

    var body: some View {
        HStack {
            Image(systemName: "person.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .foregroundColor(.gray)

            VStack(alignment: .leading) {
                Text(appointment.doctorName)
                    .font(.headline)
                Text(appointment.specialty)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text("Fees: \(doctorFees)")
                    .font(.footnote)
                    .bold()

                Text("Appointment Date: \(appointment.appointmentDate)")
                    .font(.footnote)

                Text("Appointment Slot: \(appointment.appointmentSlot)")
                    .font(.footnote)
                    .bold()
            }
            .padding(.leading, 13)
            Spacer()
        }
        .padding(.vertical, 10)
    }
}


// MARK: - Appointments Preview
struct Appointments_Previews: PreviewProvider {
    static var previews: some View {
        Appointments(patientEmail: "09")
            .environmentObject(AppointmentManager()) // ✅ Pass AppointmentManager
    }
}

