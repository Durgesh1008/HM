import SwiftUI
import Firebase
import FirebaseAuth

struct BookAppointmentView: View {
    let doctor: DoctorModel
    @State private var selectedDate = Date()
    @State private var selectedSlot: String? = nil
    @State private var selectedPatient: String? = nil
    @State private var showPatientPicker = false
    @State private var showAlert = false
    @State private var isLoading = false
    @Environment(\.presentationMode) var presentationMode
    @State private var availableSlots: [(time: String, isBooked: Bool)] = []
    
    // Assume current user ID is available from Firebase Auth
    let currentUserId = "d@gmail.com"

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                // Doctor Info
                DoctorInfoView(doctor: doctor)
                
                // Patient Selection
                SelectionRow(title: "Select Patient", value: selectedPatient ?? "Select", action: {
                    showPatientPicker.toggle()
                })
                .actionSheet(isPresented: $showPatientPicker) {
                    ActionSheet(
                        title: Text("Select Patient"),
                        buttons: PatientManager.shared.patients.map { patient in
                            .default(Text(patient.name)) { selectedPatient = patient.name }
                        } + [.cancel()]
                    )
                }

                // Date Picker
                DatePickerSection(selectedDate: $selectedDate, onDateChange: fetchSlots)

                // Available Slots
                AvailableSlotsSection(availableTimeSlots: availableSlots, selectedSlot: $selectedSlot)

                // Book Button
                BookAppointmentButton()
            }
            .padding()
        }
        .background(Color(UIColor.systemGray6))
        .navigationTitle("Book Appointment")
        .navigationBarTitleDisplayMode(.inline)
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("Booking Successful"),
                message: Text("Your appointment has been added to the schedule."),
                dismissButton: .default(Text("OK")) {
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
        .onAppear {
            fetchSlots()
        }
    }

    /// Fetches available slots from Firestore based on the selected date
    private func fetchSlots() {
        let db = Firestore.firestore()
        db.collection("doctor_schedules")
            .whereField("doctorId", isEqualTo: doctor.id)
            .getDocuments { (snapshot, error) in
                if let error = error {
                    print("❌ Firestore Error: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents, !documents.isEmpty else {
                    print("📌 No schedules found for doctor: \(doctor.id)")
                    DispatchQueue.main.async {
                        self.availableSlots = []
                    }
                    return
                }

                var slots: [(time: String, isBooked: Bool)] = []
                
                for document in documents {
                    if let timestamp = document.data()["date"] as? Timestamp {
                        let scheduleDate = timestamp.dateValue()
                        
                        if Calendar.current.isDate(scheduleDate, inSameDayAs: selectedDate) {
                            print("✅ Found schedule for selected date: \(scheduleDate)")
                            
                            if let slotsArray = document.data()["slots"] as? [[String: Any]] {
                                for slot in slotsArray {
                                    if let time = slot["time"] as? String,
                                       let isBooked = slot["isBooked"] as? Bool {
                                        slots.append((time: time, isBooked: isBooked))
                                    }
                                }
                            }
                        }
                    }
                }

                DispatchQueue.main.async {
                    self.availableSlots = slots.sorted { $0.time < $1.time }
                    print("🕐 Available Slots: \(self.availableSlots)")
                }
            }
    }

    private func BookAppointmentButton() -> some View {
        Button(action: bookAppointment) {
            Text("Book Appointment")
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, minHeight: 50)
                .background(isButtonDisabled ? Color.gray : Color.blue)
                .cornerRadius(10)
                .padding(.horizontal)
        }
        .disabled(isButtonDisabled)
        .opacity(isButtonDisabled ? 0.5 : 1.0)
    }
    
    private var isButtonDisabled: Bool {
        return selectedSlot == nil || selectedPatient == nil
    }

    /// Books an appointment in Firestore and includes user ID + status
    private func bookAppointment() {
        guard let slot = selectedSlot, let patient = selectedPatient else { return }
        
        isLoading = true
        let db = Firestore.firestore()
        let appointmentData: [String: Any] = [
            "date": selectedDate,
            "time": slot,
            "patient": patient,
            "userId": currentUserId, // 🔥 Sending user ID for doctor visibility
            "status": "Pending" // 🔥 New status field
        ]
        
        db.collection("doctors").document(doctor.id).updateData([
            "appointments": FieldValue.arrayUnion([appointmentData])
        ]) { error in
            isLoading = false
            if let error = error {
                print("Error booking appointment: \(error.localizedDescription)")
            } else {
                showAlert = true
                print("✅ Appointment booked successfully with User ID: \(currentUserId) & Status: Pending")
            }
        }
    }
}

// MARK: - Supporting Views

struct DoctorInfoView: View {
    let doctor: DoctorModel

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: "person.crop.circle.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .clipShape(Circle())
                .foregroundColor(.gray)

            VStack(alignment: .leading) {
                Text(doctor.firstName + " " + doctor.lastName)
                    .font(.title2)
                    .fontWeight(.semibold)
                Text(doctor.specialization)
                    .foregroundColor(.gray)
            }
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
    }
}

struct DatePickerSection: View {
    @Binding var selectedDate: Date
    var onDateChange: () -> Void

    var body: some View {
        VStack(alignment: .leading) {
            Text("Choose Date")
                .font(.headline)
                .padding(.top, 5)

            let minDate = Date()
            let maxDate = Calendar.current.date(byAdding: .day, value: 14, to: Date())!

            DatePicker("Appointment Date", selection: $selectedDate, in: minDate...maxDate, displayedComponents: .date)
                .datePickerStyle(GraphicalDatePickerStyle())
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .onChange(of: selectedDate) { _ in
                    onDateChange()
                }
        }
    }
}


struct AvailableSlotsSection: View {
    let availableTimeSlots: [(time: String, isBooked: Bool)]
    @Binding var selectedSlot: String?

    var body: some View {
        VStack(alignment: .leading) {
            Text("Available Slots")
                .font(.headline)

            if availableTimeSlots.isEmpty {
                Text("No available slots on this date.")
                    .foregroundColor(.red)
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .center)
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 100))], spacing: 10) {
                    ForEach(availableTimeSlots, id: \.time) { slot in
                        Button(action: {
                            if !slot.isBooked {
                                selectedSlot = slot.time
                            }
                        }) {
                            Text(slot.time)
                                .fontWeight(.semibold)
                                .foregroundColor(slot.isBooked ? .gray : (selectedSlot == slot.time ? .white : .blue))
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(slot.isBooked ? Color.red.opacity(0.5) : (selectedSlot == slot.time ? Color.blue : Color(UIColor.systemGray6)))
                                .cornerRadius(10)
                        }
                        .disabled(slot.isBooked)
                    }
                }
            }
        }
    }
}




struct AppointmentFeeSection: View {
    let fee: String
    
    var body: some View {
        HStack {
            Text("Appointment Fee:")
                .font(.headline)
            Spacer()
            Text(fee)
                .font(.headline)
                .foregroundColor(.blue)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
    }
}

