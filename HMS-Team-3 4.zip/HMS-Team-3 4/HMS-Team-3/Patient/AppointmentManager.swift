import FirebaseFirestore
import FirebaseAuth

class AppointmentManager: ObservableObject {
    static let shared = AppointmentManager() // Shared instance
    
    @Published var scheduledAppointments: [Appointment] = []
    @Published var completedAppointments: [Appointment] = []
    @Published var doctorFeesDict: [String: String] = [:]
    
    private let db = Firestore.firestore()
    private var patientEmail: String = "" // Store patient email

    func setPatientEmail(_ email: String) {
        self.patientEmail = "patient@gmail.com"
        fetchAppointments()
    }
    
    func fetchAppointments() {
        guard !patientEmail.isEmpty else {
            print("❌ No patient email set. Cannot fetch appointments.")
            return
        }

        db.collection("doctors").getDocuments { snapshot, error in
            if let error = error {
                print("❌ Error fetching doctors: \(error.localizedDescription)")
                return
            }
            
            guard let docs = snapshot?.documents else { return }
            
            var scheduled: [Appointment] = []
            var completed: [Appointment] = []
            var feesDict: [String: String] = [:]
            
            for doc in docs {
                let doctorData = doc.data()
                let doctorName = doctorData["firstName"] as? String ?? "Unknown Doctor"
                let specialty = doctorData["specialization"] as? String ?? "General"
                let fees = doctorData["outpatientFees"] as? String ?? "N/A"
                feesDict[doctorName] = fees
                
                if let appointments = doctorData["appointments"] as? [[String: Any]] {
                    for dict in appointments {
                        guard let patientId = dict["userId"] as? String, patientId == self.patientEmail,
                              let date = (dict["date"] as? Timestamp)?.dateValue(),
                              let status = dict["status"] as? String, // ✅ Status from DB
                              let time = dict["time"] as? String else { continue }
                        
                        let appointment = Appointment(
                            doctorName: doctorName,
                            specialty: specialty,
                            appointmentDate: date.toFormattedString(),
                            appointmentSlot: time
                            
                        )
                        
                        if status == "Approved" {
                            completed.append(appointment) // Store completed separately
                        } else {
                            scheduled.append(appointment) // Store scheduled separately
                        }
                    }
                }
            }
            
            DispatchQueue.main.async {
                self.scheduledAppointments = scheduled
                self.completedAppointments = completed
                self.doctorFeesDict = feesDict
            }
        }
    }
    
    func addAppointment(_ appointment: Appointment, forDoctor doctorId: String) {
        guard !patientEmail.isEmpty else {
            print("❌ No patient email set. Cannot book appointment.")
            return
        }

        let appointmentData: [String: Any] = [
            "userId": patientEmail,
            "date": Timestamp(date: Date()), // Use selectedDate if available
            "time": appointment.appointmentSlot,
            "status": "Scheduled"
        ]

        let doctorRef = db.collection("doctors").document(doctorId)

        doctorRef.updateData([
            "appointments": FieldValue.arrayUnion([appointmentData])
        ]) { error in
            if let error = error {
                print("❌ Error adding appointment: \(error.localizedDescription)")
            } else {
                print("✅ Appointment booked successfully!")
                DispatchQueue.main.async {
                    self.scheduledAppointments.append(appointment)
                }
            }
        }
    }


    
}
extension Date {
    func toFormattedString() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: self)
    }
}
