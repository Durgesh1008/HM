import SwiftUI

struct CompletedAppointment: View {
    var appointment: DoctorAppointment

    @State private var selectedRating: Int? = nil
    @State private var reviewText: String = ""
    @State private var showReviewSubmittedAlert = false // 1️⃣ State for Alert

    var body: some View {
        VStack(spacing: 16) {
            // Doctor Info
            HStack(spacing: 16) {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.gray)
                VStack(alignment: .leading, spacing: 4) {
                    Text(appointment.doctorName)
                        .font(.title3)
                        .fontWeight(.semibold)
                    Text(appointment.specialty)
                        .foregroundColor(.gray)
                }
                Spacer()
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
            .padding(.horizontal)

            // Appointment Details
            VStack(alignment: .leading, spacing: 12) {
                detailRow(title: "Appointment Date", value: appointment.appointmentDate)
                detailRow(title: "Appointment Slot", value: appointment.appointmentSlot)
                detailRow(title: "Payment Status", value: "\(appointment.paymentStatus) (\(appointment.paymentState))")
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
            .padding(.horizontal)

            // Rating Section
            VStack(spacing: 12) {
                Text("Rate Your Experience")
                    .font(.headline)

                // Star Rating System
                HStack(spacing: 8) {
                    ForEach(1...5, id: \.self) { index in
                        Image(systemName: index <= (selectedRating ?? 0) ? "star.fill" : "star")
                            .resizable()
                            .frame(width: 24, height: 24)
                            .foregroundColor(index <= (selectedRating ?? 0) ? .yellow : .gray)
                            .onTapGesture {
                                selectedRating = index
                            }
                    }
                }

                // Review TextField
                TextField("Write Your Review Here", text: $reviewText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                // Submit Review Button
                Button(action: {
                    // Submit review action
                    print("Review Submitted: Rating \(selectedRating ?? 0), Review: \(reviewText)")
                    showReviewSubmittedAlert = true // 2️⃣ Trigger the alert
                }) {
                    Text("Submit Review")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background((selectedRating != nil && !reviewText.isEmpty) ? Color.blue : Color.gray)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                .disabled(selectedRating == nil || reviewText.isEmpty) // Disable if no rating or no review
                .alert(isPresented: $showReviewSubmittedAlert) { // 3️⃣ Alert presentation
                    Alert(
                        title: Text("Success"),
                        message: Text("Review submitted"),
                        dismissButton: .default(Text("OK")) {
                            // Optional: Clear form after submission
                            selectedRating = nil
                            reviewText = ""
                        }
                    )
                }
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
            .padding(.horizontal)

            Spacer()
        }
        .background(Color("F2F2F7").ignoresSafeArea())
        .navigationTitle("Appointment Detail")
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder
    private func detailRow(title: String, value: String) -> some View {
        HStack {
            Text(title)
                .foregroundColor(.gray)
            Spacer()
            Text(value)
                .fontWeight(.semibold)
        }
    }
}

