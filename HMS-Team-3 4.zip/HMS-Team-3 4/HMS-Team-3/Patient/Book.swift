import SwiftUI

struct BookView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedSlot: String? = nil
    @EnvironmentObject var appointmentManager: AppointmentManager

    let doctor: DoctorModel
    let selectedDate: Date

    var formattedSelectedDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter.string(from: selectedDate)
    }

    var availableSlots: [String] {
        // This logic needs to be adjusted based on where the schedule data is stored.
        return [] // Replace this with actual data retrieval
    }

    var body: some View {
        VStack {
            PatientDoctorProfileView(doctor: doctor)

            Text("Available Slots")
                .font(.headline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)
                .padding(.top, 10)

            AvailableSlotsGrid(availableSlots: availableSlots, selectedSlot: $selectedSlot)

            Spacer()

            BookAppointmentButton()
        }
        .navigationTitle("Book Appointment")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button("Doctors") {
                    presentationMode.wrappedValue.dismiss()
                }
                .foregroundColor(.blue)
            }
        }
        .background(Color(UIColor.systemGray6).ignoresSafeArea())
    }

    private func BookAppointmentButton() -> some View {
        Button(action: {
            if let selectedSlot = selectedSlot {
                let formatter = DateFormatter()
                formatter.dateFormat = "dd MMM yyyy"
                let formattedDate = formatter.string(from: selectedDate)

                let newAppointment = Appointment(
                    doctorName: doctor.firstName + " " + doctor.lastName,
                    specialty: doctor.specialization,
                    appointmentDate: formattedDate,
                    appointmentSlot: selectedSlot
                )

                AppointmentManager.shared.addAppointment(newAppointment, forDoctor: doctor.id) // ✅ Pass doctor ID
                presentationMode.wrappedValue.dismiss()
            }
        }) {
            Text("Book Appointment")
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity, minHeight: 50)
                .background(Color.blue)
                .cornerRadius(10)
                .padding(.horizontal)
        }

        .disabled(selectedSlot == nil)
        .opacity(selectedSlot == nil ? 0.5 : 1.0)
    }
}

// MARK: - Doctor Profile View
struct PatientDoctorProfileView: View {
    let doctor: DoctorModel

    var body: some View {
        HStack(spacing: 16) {
            if let image = UIImage(named: doctor.firstName), !doctor.firstName.isEmpty {
                Image(uiImage: image)
                    .resizable()
                    .frame(width: 80, height: 80)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .shadow(radius: 2)
            } else {
                Image(systemName: "person.crop.square.fill")
                    .resizable()
                    .frame(width: 80, height: 80)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }

            VStack(alignment: .leading) {
                Text(doctor.firstName + " " + doctor.lastName)
                    .font(.title2)
                    .fontWeight(.bold)

                Text(doctor.specialization)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            Spacer()
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).shadow(radius: 2))
        .padding(.horizontal)
    }
}

// MARK: - Available Slots Grid
struct AvailableSlotsGrid: View {
    let availableSlots: [String]
    @Binding var selectedSlot: String?

    var body: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
            ForEach(availableSlots, id: \.self) { slot in
                Button {
                    selectedSlot = slot
                } label: {
                    Text(slot)
                        .fontWeight(.semibold)
                        .foregroundColor(selectedSlot == slot ? .white : .blue)
                        .padding(.vertical, 10)
                        .frame(maxWidth: .infinity)
                        .background(selectedSlot == slot ? Color.blue : Color.clear)
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.blue, lineWidth: 2))
                }
            }
        }
        .padding(.horizontal)
        .padding(.top, 5)
    }
}
