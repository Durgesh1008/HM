import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct ProfileView: View {
    @State private var isAddUserPresented = false
    @State private var users: [User] = []
    @State private var isEditUserPresented = false
    var patientEmail: String
    @State private var loggedInPatient: Patient?

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                
                // Horizontal Scroll for Profile Selection
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 30) {
                        ProfileButton(user: nil, isSelected: loggedInPatient != nil) {
                            loggedInPatient = nil
                        }
                        ForEach(users, id: \.id) { user in
                            ProfileButton(user: user, isSelected: loggedInPatient?.id == user.id) {
                                loggedInPatient = nil
                            }
                        }
                        AddFamilyButton { isAddUserPresented = true }
                    }
                    .padding(.horizontal)
                }
                .padding(.top, 20)

                // User Details
                if let patient = loggedInPatient {
                    PatientDetailsView(patient: patient)
                }


                // Navigation Links
                VStack(spacing: 10) {
                    NavigationLink(destination: ChangeHospitalView(patientEmail: patientEmail)) {
                        ActionRow(title: "Change Hospital")
                    }

                    NavigationLink(destination: PatientChangePasswordView(patientEmail: patientEmail)) {
                        ActionRow(title: "Change Password")
                    }
                }
                .padding(.horizontal)

                Spacer()

                // Logout Button
                Button(action: {
                    do {
                        try Auth.auth().signOut()
                        UIApplication.shared.windows.first?.rootViewController = UIHostingController(rootView: LoginView())
                    } catch let signOutError {
                        print("Error signing out: \(signOutError.localizedDescription)")
                    }
                }) {
                    Text("Log Out")
                        .font(.body)
                        .fontWeight(.bold)
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 2)
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            .navigationTitle("Profile")
            .background(Color(UIColor.systemGroupedBackground))
            .sheet(isPresented: $isAddUserPresented) {
                AddUserView(users: $users, patientEmail: patientEmail)
            }
            .onAppear {
                fetchPatientData()
            }
        }
    }
    
    
    
    // Fetch logged-in patient data and family members
    private func fetchPatientData() {
           let db = Firestore.firestore()
           db.collection("patients").whereField("email", isEqualTo: patientEmail).getDocuments { snapshot, error in
               if let error = error {
                   print("Error fetching patient: \(error.localizedDescription)")
                   return
               }
               
               guard let document = snapshot?.documents.first else { return }
               let data = document.data()
               loggedInPatient = Patient(
                   name: data["name"] as? String ?? "",
                   age: data["age"] as? String ?? "",
                   gender: data["gender"] as? String ?? "",
                   phoneNumber: data["phoneNumber"] as? String ?? "",
                   email: data["email"] as? String ?? ""
               )
               
               if let familyArray = data["family_members"] as? [[String: Any]] {
                   users = familyArray.compactMap { memberData in
                       return User(
                           name: memberData["name"] as? String ?? "",
                           age: memberData["age"] as? String ?? "",
                           gender: memberData["gender"] as? String ?? "",
                           phoneNumber: memberData["phoneNumber"] as? String ?? "",
                           email: memberData["email"] as? String ?? "",
                           relation: memberData["relation"] as? String ?? ""
                       )
                   }
               }
           }
       }
   }

struct AddUserView: View {
    @Binding var users: [User]
    var patientEmail: String
    @Environment(\.presentationMode) var presentationMode
    
    @State private var name = ""
    @State private var age = ""
    @State private var gender = ""
    @State private var phoneNumber = ""
    @State private var relation = ""
    
    var body: some View {
        VStack {
            Text("Add Family Member").font(.title).padding()
            TextField("Name", text: $name).textFieldStyle(RoundedBorderTextFieldStyle()).padding()
            TextField("Age", text: $age).textFieldStyle(RoundedBorderTextFieldStyle()).padding()
            TextField("Gender", text: $gender).textFieldStyle(RoundedBorderTextFieldStyle()).padding()
            TextField("Phone Number", text: $phoneNumber).textFieldStyle(RoundedBorderTextFieldStyle()).padding()
            TextField("Relation", text: $relation).textFieldStyle(RoundedBorderTextFieldStyle()).padding()
            
            Button("Add User") {
                let db = Firestore.firestore()
                db.collection("patients").whereField("email", isEqualTo: patientEmail).getDocuments { snapshot, error in
                    guard let document = snapshot?.documents.first else { return }
                    let patientID = document.documentID
                    
                    let newUserData: [String: Any] = [
                        "name": name,
                        "age": age,
                        "gender": gender,
                        "phoneNumber": phoneNumber,
                        "relation": relation
                    ]
                    
                    db.collection("patients").document(patientID).updateData([
                        "family_members": FieldValue.arrayUnion([newUserData])
                    ]) { error in
                        if error == nil {
                            let newUser = User(
                                name: name,
                                age: age,
                                gender: gender,
                                phoneNumber: phoneNumber,
                                email: "",
                                relation: relation
                            )
                            users.append(newUser)
                            presentationMode.wrappedValue.dismiss()
                        }
                    }
                }
            }
            .padding()
        }
        .padding()
    }
    
    
    private func fetchFamilyMembers(for patientID: String) {
        let db = Firestore.firestore()
        
        db.collection("patients").document(patientID).getDocument { snapshot, error in
            if let error = error {
                print("Error fetching family members: \(error.localizedDescription)")
                return
            }
            
            guard let document = snapshot, document.exists else {
                print("Patient document not found")
                return
            }
            
            if let familyMembersData = document.data()?["family_members"] as? [[String: Any]] {
                users = familyMembersData.compactMap { data in
                    return User(
                        name: data["name"] as? String ?? "",
                        age: data["age"] as? String ?? "",
                        gender: data["gender"] as? String ?? "",
                        phoneNumber: data["phoneNumber"] as? String ?? "",
                        email: data["email"] as? String ?? "",
                        relation: data["relation"] as? String ?? ""
                    )
                }
            } else {
                users = []  // No family members found
            }
        }
    }
}
    
    
    
    
    // MARK: - Profile Button
    struct ProfileButton: View {
        var user: User?
        var isSelected: Bool
        var action: () -> Void
        
        var body: some View {
            Button(action: action) {
                VStack {
                    Circle()
                        .fill(isSelected ? Color.blue : Color.gray)
                        .frame(width: 60, height: 60)
                        .overlay(Text(user?.name.prefix(1) ?? "P").foregroundColor(.white))
                    Text(user?.name ?? "You")
                        .font(.caption)
                }
            }
        }
    }
    
    // MARK: - Add Family Button
    struct AddFamilyButton: View {
        var action: () -> Void
        
        var body: some View {
            Button(action: action) {
                VStack {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 60, height: 60)
                        .overlay(Image(systemName: "plus").foregroundColor(.white))
                    Text("Add")
                        .font(.caption)
                }
            }
        }
    }
    
    
    // MARK: - User Details View
    struct UserDetailsView: View {
        let user: User
        
        var body: some View {
            VStack {
                Text("Family Member Profile")
                    .font(.title)
                
                Text("Name: \(user.name)")
                Text("Age: \(user.age)")
                Text("Gender: \(user.gender)")
                Text("Phone: \(user.phoneNumber)")
                Text("Email: \(user.email)")
                Text("Relation: \(user.relation)")
            }
            .padding()
        }
    }
    
    
    // MARK: - Action Row
    struct ActionRow: View {
        var title: String
        
        var body: some View {
            HStack {
                Text(title)
                    .font(.body)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 2)
        }
    }
    
    
    struct EditPatientView: View {
        @Binding var patient: Patient?
        @Environment(\.presentationMode) var presentationMode
        
        var body: some View {
            VStack {
                Text("Edit Patient")
                    .font(.title)
                    .padding()
                
                if let patient = patient { // ✅ Ensure patient exists
                    TextField("Name", text: Binding(
                        get: { patient.name },
                        set: { self.patient?.name = $0 }
                    ))
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    
                    TextField("Phone Number", text: Binding(
                        get: { patient.phoneNumber ?? "78" },
                        set: { self.patient?.phoneNumber = $0 }
                    ))
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    
                    Button("Save Changes") {
                        // Save to Firestore if needed
                        presentationMode.wrappedValue.dismiss()
                    }
                    .padding()
                }
            }
            .padding()
        }
    }
    
    struct PatientDetailsView: View {
        let patient: Patient
        
        var body: some View {
            VStack {
                Text("Patient Profile")
                    .font(.title)
                
                Text("Name: \(patient.name)")
                Text("Age: \(patient.age)")
                Text("Gender: \(patient.gender)")
                Text("Phone: \(patient.phoneNumber)")
                Text("Email: \(patient.email)")
                Text("Appointment: \(patient.appointmentDate) at \(patient.appointmentSlot)")
            }
            .padding()
        }
    }
    

