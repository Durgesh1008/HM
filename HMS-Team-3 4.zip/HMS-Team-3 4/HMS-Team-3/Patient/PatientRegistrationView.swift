import SwiftUI
import Firebase
import MapKit

struct PatientRegistrationView: View {
    @State private var name: String = ""
    @State private var age: String = ""
    @State private var gender: String = "Select Gender"
    @State private var phoneNumber: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var locationName: String = ""

    @State private var errorMessage: String = ""
    @State private var passwordErrorMessage: String = ""
    @State private var isLoading = false
    @State private var showLocationPicker = false

    let genders = ["Male", "Female", "Other"]

    var isFormValid: Bool {
        return !name.isEmpty &&
               !age.isEmpty &&
               gender != "Select Gender" &&
               phoneNumber.count >= 10 &&
               email.contains("@") &&
               !locationName.isEmpty &&
               !password.isEmpty &&
               password == confirmPassword &&
               errorMessage.isEmpty &&
               passwordErrorMessage.isEmpty
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Patient Registration")
                    .font(.largeTitle)
                    .bold()
                    .padding(.top, 20)

                FormTextField(title: "Full Name", text: $name)
                FormTextField(title: "Age", text: $age, keyboardType: .numberPad)

                // Gender Picker
                Picker("Gender", selection: $gender) {
                    Text("Select Gender").tag("Select Gender")
                    ForEach(genders, id: \.self) { Text($0).tag($0) }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 1)

                FormTextField(title: "Phone Number", text: $phoneNumber, keyboardType: .phonePad)

                // Email Field with Error Message
                VStack(alignment: .leading, spacing: 5) {
                    FormTextField(title: "Email", text: $email, keyboardType: .emailAddress)
                        .onChange(of: email) { newValue in
                            checkIfEmailExists(newValue)
                        }

                    if !errorMessage.isEmpty {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                }

                // Password Fields
                SecureFormTextField(title: "Password", text: $password)
                    .onChange(of: password) { _ in validatePassword() }

                VStack(alignment: .leading, spacing: 5) {
                    SecureFormTextField(title: "Confirm Password", text: $confirmPassword)
                        .onChange(of: confirmPassword) { _ in validatePassword() }

                    if !passwordErrorMessage.isEmpty {
                        Text(passwordErrorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                }

                // Location Picker Styled Like a Form Field
                Button(action: { showLocationPicker.toggle() }) {
                    HStack {
                        Text(locationName.isEmpty ? "Select Location" : locationName)
                            .foregroundColor(locationName.isEmpty ? .gray : .primary)

                        Spacer()

                        Image(systemName: "location.fill")
                            .foregroundColor(.blue)
                    }
                    .padding()
                    .background(Color(.systemBackground))
                    .cornerRadius(10)
                    .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 1)
                }

                // Register Button
                Button(action: registerUser) {
                    Text(isLoading ? "Registering..." : "Register")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(isFormValid ? Color.blue : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .shadow(radius: 3)
                }
                .disabled(!isFormValid || isLoading)
                Button("Already have an account? Login") {
                    redirectToLoginView()
                }
                .foregroundColor(.blue)
                .padding(.top, 10)

                Spacer()
            }
            .padding()
        }
        .sheet(isPresented: $showLocationPicker) {
            LocationSearchViews(selectedLocationName: $locationName)
        }
    }

    // 🔹 Check if email exists in other collections
    func checkIfEmailExists(_ email: String) {
        let db = Firestore.firestore()
        let collectionsToCheck = ["superAdmins", "admin_credentials", "doctor_creds","patients"]
        var emailFound = false

        let group = DispatchGroup()

        for collection in collectionsToCheck {
            group.enter()
            db.collection(collection)
                .whereField("email", isEqualTo: email)
                .getDocuments { snapshot, _ in
                    if let snapshot = snapshot, !snapshot.documents.isEmpty {
                        emailFound = true
                    }
                    group.leave()
                }
        }

        group.notify(queue: .main) {
            if emailFound {
                errorMessage = "This email is already registered in another category."
            } else {
                errorMessage = ""
            }
        }
    }

    // 🔹 Validate Password and Confirm Password Match
    func validatePassword() {
        if password != confirmPassword {
            passwordErrorMessage = "Passwords do not match."
        } else {
            passwordErrorMessage = ""
        }
    }

    // 🔹 Register User
    func registerUser() {
        guard !locationName.isEmpty else { return }

        isLoading = true
        let db = Firestore.firestore()
        let newPatientRef = db.collection("patients").document()
        let patientID = newPatientRef.documentID

        let newPatient: [String: Any] = [
            "id": patientID,
            "name": name,
            "age": age,
            "gender": gender,
            "phoneNumber": phoneNumber,
            "email": email,
            "password": password, // Hashing recommended
            "location": locationName,
            "timestamp": Timestamp()
        ]

        newPatientRef.setData(newPatient) { error in
            isLoading = false
            if error == nil {
                redirectToLoginView()
            }
        }
    }
}

// 🔹 Secure Form Text Field
struct SecureFormTextField: View {
    var title: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)

            SecureField(title, text: $text)
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 1)
        }
    }
}



// 🔹 Location Search View
struct LocationSearchViews: View {
    @ObservedObject var viewModel = LocationSearchViewModel()
    @Binding var selectedLocationName: String
    @Environment(\.presentationMode) var presentationMode
    
    @State private var searchText = ""

    var body: some View {
        NavigationView {
            VStack {
                TextField("Search for a location...", text: $searchText, onEditingChanged: { _ in
                    viewModel.updateSearch(query: searchText)
                })
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
                .padding()

                List(viewModel.searchResults, id: \.title) { result in
                    Button(action: {
                        selectedLocationName = result.title
                        presentationMode.wrappedValue.dismiss() // Close sheet
                    }) {
                        VStack(alignment: .leading) {
                            Text(result.title).font(.headline)
                            Text(result.subtitle).font(.subheadline).foregroundColor(.gray)
                        }
                    }
                }
            }
            .navigationTitle("Select Location")
        }
    }
}


class LocationSearchViewModel: NSObject, ObservableObject, MKLocalSearchCompleterDelegate {
    @Published var searchResults: [MKLocalSearchCompletion] = []
    private var searchCompleter = MKLocalSearchCompleter()

    override init() {
        super.init()
        searchCompleter.delegate = self
        searchCompleter.resultTypes = .address
    }

    func updateSearch(query: String) {
        searchCompleter.queryFragment = query
    }

    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        DispatchQueue.main.async {
            self.searchResults = completer.results
        }
    }

    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        print("Location search failed: \(error.localizedDescription)")
    }
}


// 🔹 Search Completer Delegate
class SearchCompleterDelegate: NSObject, MKLocalSearchCompleterDelegate {
    var completionHandler: (([MKLocalSearchCompletion]) -> Void)?
    
    init(completionHandler: @escaping ([MKLocalSearchCompletion]) -> Void) {
        self.completionHandler = completionHandler
    }
    
    override init() { }
    
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        completionHandler?(completer.results)
    }
    
    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        print("Location search failed: \(error.localizedDescription)")
    }
}

    // 🔹 Redirect to Login View using Window Replacement
    func redirectToLoginView() {
        if let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap({ $0.windows })
            .first(where: { $0.isKeyWindow }) {
            window.rootViewController = UIHostingController(rootView: LoginView())
            window.makeKeyAndVisible()
        }
    }


// 🔹 Reusable Form Text Field
struct FormTextField: View {
    var title: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)
            
            TextField(title, text: $text)
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 1)
                .keyboardType(keyboardType)
                .autocapitalization(.none)
        }
    }
}
