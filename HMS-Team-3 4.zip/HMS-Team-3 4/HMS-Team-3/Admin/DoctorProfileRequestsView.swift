//
//  DoctorProfileRequestsView.swift
//  HMS-Team-3
//
//  Created by DIWAKAR KUMAR on 20/02/25.
//

import SwiftUI

struct DoctorProfileRequestsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    DoctorProfileRequestsView()
}
