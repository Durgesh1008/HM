import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth
import Charts

struct AdminDashboardView: View {
    let hospitalId: String
    @StateObject private var viewModel = AdminDashboardViewModel()
    @State private var timer: Timer?

    var body: some View {
        TabView {
            NavigationStack {
                DashboardView(viewModel: viewModel)
            }
            .tabItem {
                Image(systemName: "house.fill")
                Text("Dashboard")
            }
            
            NavigationStack {
                DoctorListView(hospitalId: hospitalId)
            }
            .tabItem {
                Image(systemName: "person.2.fill")
                Text("Doctors")
            }

            NavigationStack {
                AdminLeaveDashboard(hospitalId: hospitalId)
            }
            .tabItem {
                Image(systemName: "list.bullet.clipboard.fill")
                Text("Leave")
            }
            
            NavigationStack {
                AdminProfile(hospitalId: hospitalId)
            }
            .tabItem {
                Image(systemName: "person.crop.circle.fill")
                Text("Profile")
            }
        }
        .background(Color(.systemGray6))
        .onAppear {
            fetchDashboardData()
            startAutoRefresh()
        }
        .onDisappear {
            stopAutoRefresh()
        }
    }
    
    private func fetchDashboardData() {
        viewModel.fetchHospitalData(hospitalId: hospitalId)
        viewModel.fetchDoctorCount(hospitalId: hospitalId)
        viewModel.fetchLeaveCount(hospitalId: hospitalId) // ✅ Fetch leave applications count
    }

    /// Start a timer to auto-refresh the dashboard every 30 seconds
    private func startAutoRefresh() {
        timer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { _ in
            fetchDashboardData()
        }
    }

    /// Stop the timer when leaving the view
    private func stopAutoRefresh() {
        timer?.invalidate()
        timer = nil
    }
}

// MARK: - Dashboard View
struct DashboardView: View {
    @ObservedObject var viewModel: AdminDashboardViewModel

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // *Header - Hospital Name*
                HStack {
                    Text(viewModel.hospitalName.isEmpty ? "Loading..." : viewModel.hospitalName)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Spacer()
                }
                .padding(.horizontal)

                // *Bar Chart*
                AdminChartView(revenue: viewModel.totalRevenue, dues: viewModel.unpaidDues, expenses: viewModel.expenses)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .fill(Color.white)
                            .shadow(color: Color.black.opacity(0.1), radius: 3)
                    )
                    .padding(.horizontal)

                // *Financial Overview*
                HStack(spacing: 12) {
                    FinanceCard(title: "Total Revenue", amount: "$\(viewModel.totalRevenue)", color: .green)
                    FinanceCard(title: "Unpaid Dues", amount: "$\(viewModel.unpaidDues)", color: .blue)
                    FinanceCard(title: "Expenses", amount: "$\(viewModel.expenses)", color: .red)
                }
                .padding(.horizontal)

                // *Activity Overview*
                // *Activity Overview*
                // *Activity Overview*
                // *Activity Overview*
                VStack(alignment: .leading, spacing: 8) {
                    Text("Activity Overview")
                        .font(.headline)
                        .padding(.horizontal)

                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                        ActivityCard(icon: "stethoscope", label: "\(viewModel.doctorCount)", description: "Doctors", color: .blue.opacity(0.2))
                        ActivityCard(icon: "person.2.fill", label: "50", description: "New Patients", color: .green.opacity(0.2)) // Placeholder
                        ActivityCard(icon: "calendar.badge.clock", label: "\(viewModel.leaveCount)", description: "Leave Applications", color: .orange.opacity(0.2))
//                        ActivityCard(icon: "doc.text", label: "100", description: "Reports", color: .purple.opacity(0.2)) // Example
                    }
                    .frame(maxWidth: .infinity) // Ensure full width
                    .padding(.horizontal)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .shadow(color: Color.black.opacity(0.1), radius: 3)
                )
                .padding(.horizontal)




                Spacer()
            }
            .padding(.top)
        }
        .background(Color(.systemGray6))
    }
}

// MARK: - ViewModel for Firestore Data Fetching
class AdminDashboardViewModel: ObservableObject {
    @Published var hospitalName: String = "Loading..."
    @Published var totalRevenue: Double = 0.0
    @Published var unpaidDues: Double = 0.0
    @Published var expenses: Double = 0.0
    @Published var doctorCount: Int = 0
    @Published var leaveCount: Int = 0  // ✅ New leave count property

    private let db = Firestore.firestore()

    func fetchHospitalData(hospitalId: String) {
        db.collection("hospitals").document(hospitalId).getDocument { document, error in
            if let error = error {
                print("Error fetching hospital data: \(error.localizedDescription)")
                return
            }

            if let data = document?.data() {
                DispatchQueue.main.async {
                    self.hospitalName = data["name"] as? String ?? "Unknown Hospital"
                    self.totalRevenue = data["totalRevenue"] as? Double ?? 0.0
                    self.unpaidDues = data["unpaidDues"] as? Double ?? 0.0
                    self.expenses = data["expenses"] as? Double ?? 0.0
                }
            }
        }
    }

    func fetchDoctorCount(hospitalId: String) {
        db.collection("doctors").whereField("hospitalId", isEqualTo: hospitalId).getDocuments { snapshot, error in
            DispatchQueue.main.async {
                self.doctorCount = snapshot?.documents.count ?? 0
            }
        }
    }

    /// ✅ Fetch total leave applications count
    func fetchLeaveCount(hospitalId: String) {
        db.collection("leaveRequests").whereField("hospitalId", isEqualTo: hospitalId).getDocuments { snapshot, error in
            DispatchQueue.main.async {
                self.leaveCount = snapshot?.documents.count ?? 0
            }
        }
    }
}

// MARK: - Finance Card
struct FinanceCard: View {
    var title: String
    var amount: String
    var color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.gray)

            Text(amount)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(color)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 100)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.1), radius: 3)
        )
    }
}

// MARK: - Activity Card
struct ActivityCard: View {
    var icon: String
    var label: String
    var description: String
    var color: Color
    
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundColor(.black)
            Text(label)
                .font(.title3)
                .fontWeight(.bold)
            Text(description)
                .font(.subheadline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center) // Ensure text stays aligned
        }
        .frame(maxWidth: .infinity, minHeight: 120, maxHeight: 120) // Same height for all
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(color)
                .shadow(color: Color.black.opacity(0.1), radius: 3)
        )
    }
}





struct AdminChartView: View {
    var revenue: Double
    var dues: Double
    var expenses: Double

    var body: some View {
        VStack {
            Text(formattedDate())
                .font(.headline)
                .padding(.bottom, 8)

            Chart {
                BarMark(x: .value("Category", "Revenue"), y: .value("Amount", revenue))
                    .foregroundStyle(.green)
                BarMark(x: .value("Category", "Dues"), y: .value("Amount", dues))
                    .foregroundStyle(.blue)
                BarMark(x: .value("Category", "Expenses"), y: .value("Amount", expenses))
                    .foregroundStyle(.red)
            }
            .frame(height: 150)
        }
    }
}

// Function to format date
func formattedDate() -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "dd MMM yyyy"
    return formatter.string(from: Date())
}

// MARK: - Preview
struct AdminDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        AdminDashboardView(hospitalId: "dummyHospitalId")
    }
}

